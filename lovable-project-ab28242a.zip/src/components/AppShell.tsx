import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Users,
  BedDouble,
  DoorOpen,
  Tags,
  ConciergeBell,
  Sparkles,
  Wrench,
  UtensilsCrossed,
  ClipboardList,
  CalendarClock,
  Bell,
  Search,
  BookOpen,
  UserCircle2,
  Hotel,
  LogOut,
} from "lucide-react";
import { type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { initialNotifications } from "@/lib/mock-data";
import { canAccess, useAuth } from "@/lib/auth";
import { toast } from "sonner";

type NavItem = { to: string; label: string; icon: React.ComponentType<{ className?: string }> };

const groups: { title: string; items: NavItem[] }[] = [
  {
    title: "Overview",
    items: [{ to: "/", label: "Revenue Dashboard", icon: LayoutDashboard }],
  },
  {
    title: "Guest",
    items: [
      { to: "/booking", label: "Book a Stay", icon: Search },
      { to: "/reservations", label: "My Reservations", icon: BookOpen },
      { to: "/profile", label: "Guest Profile", icon: UserCircle2 },
    ],
  },
  {
    title: "Front Desk",
    items: [
      { to: "/front-desk", label: "Arrivals & Departures", icon: ConciergeBell },
    ],
  },
  {
    title: "Housekeeping",
    items: [
      { to: "/housekeeping", label: "Task Board", icon: Sparkles },
      { to: "/maintenance", label: "Maintenance", icon: Wrench },
    ],
  },
  {
    title: "F&B",
    items: [
      { to: "/menu", label: "Menu", icon: UtensilsCrossed },
      { to: "/orders", label: "Orders", icon: ClipboardList },
      { to: "/dining", label: "Dining Reservations", icon: CalendarClock },
    ],
  },
  {
    title: "Admin",
    items: [
      { to: "/room-types", label: "Room Types", icon: BedDouble },
      { to: "/rooms", label: "Rooms", icon: DoorOpen },
      { to: "/rate-plans", label: "Rate Plans", icon: Tags },
      { to: "/users", label: "Users", icon: Users },
    ],
  },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const unread = initialNotifications.filter((n) => n.status === "UNREAD").length;
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const visibleGroups = groups
    .map((g) => ({
      ...g,
      items: g.items.filter((i) => (user ? canAccess(user.role, i.to) : false)),
    }))
    .filter((g) => g.items.length > 0);

  const initials = user
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .slice(0, 2)
        .join("")
    : "?";

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex items-center gap-2 px-5 py-5 border-b border-sidebar-border">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-[color:var(--gold)]/20 text-[color:var(--gold)]">
            <Hotel className="h-5 w-5" />
          </div>
          <div>
            <div className="font-serif text-lg leading-none">StayNest</div>
            <div className="text-[10px] uppercase tracking-widest text-sidebar-foreground/60">
              Hospitality OS
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          {visibleGroups.map((g) => (
            <div key={g.title} className="mb-4">
              <div className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/50">
                {g.title}
              </div>
              {g.items.map((i) => {
                const active = pathname === i.to || (i.to !== "/" && pathname.startsWith(i.to));
                const Icon = i.icon;
                return (
                  <Link
                    key={i.to}
                    to={i.to}
                    className={cn(
                      "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors",
                      active
                        ? "bg-sidebar-accent text-sidebar-foreground"
                        : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{i.label}</span>
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="border-t border-sidebar-border px-4 py-3 text-xs text-sidebar-foreground/60">
          v1.0 · Phase 2 preview
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-background/85 px-6 backdrop-blur">
          <div className="md:hidden flex items-center gap-2">
            <Hotel className="h-5 w-5 text-primary" />
            <span className="font-serif text-lg">StayNest</span>
          </div>
          <div className="hidden md:block text-sm text-muted-foreground">
            Welcome back —{" "}
            <span className="text-foreground font-medium">{user?.name ?? "Guest"}</span>
            {user && <> · {user.role}</>}
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/notifications"
              className="relative rounded-full p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
              aria-label="Notifications"
            >
              <Bell className="h-5 w-5" />
              {unread > 0 && (
                <Badge className="absolute -right-1 -top-1 h-4 min-w-4 justify-center rounded-full bg-destructive px-1 text-[10px] text-destructive-foreground">
                  {unread}
                </Badge>
              )}
            </Link>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground grid place-items-center text-sm font-semibold">
                {initials}
              </div>
              <div className="hidden text-xs sm:block">
                <div className="font-medium">{user?.name}</div>
                <div className="text-muted-foreground">{user?.email}</div>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                logout();
                toast.success("Signed out");
                navigate({ to: "/login" });
              }}
              className="gap-1.5"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sign out</span>
            </Button>
          </div>
        </header>
        <main className="flex-1 min-w-0 px-6 py-8">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-serif text-3xl">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}
