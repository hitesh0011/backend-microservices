import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { initialUsers, type Role, type User } from "@/lib/mock-data";

// Guest demo account (not part of staff user list)
const guestDemo: User = {
  id: 999,
  name: "Priya Menon",
  role: "GUEST",
  email: "priya.menon@example.com",
  phone: "+91 98450 12345",
  property: "—",
  status: "ACTIVE",
};

export const demoAccounts: User[] = [...initialUsers.filter((u) => u.status === "ACTIVE"), guestDemo];

// Route access by role. Prefix match; "*" = all.
const roleRoutes: Record<Role, string[]> = {
  ADMIN: ["*"],
  FRONTDESK: [
    "/",
    "/front-desk",
    "/stays",
    "/reservations",
    "/rooms",
    "/room-types",
    "/rate-plans",
    "/notifications",
    "/housekeeping",
  ],
  HOUSEKEEPING: ["/housekeeping", "/maintenance", "/rooms", "/notifications"],
  FBMANAGER: ["/menu", "/orders", "/dining", "/notifications"],
  REVENUEMANAGER: ["/", "/room-types", "/rate-plans", "/reservations", "/notifications"],
  GUEST: ["/booking", "/reservations", "/profile"],
};

export function canAccess(role: Role, path: string): boolean {
  const allowed = roleRoutes[role];
  if (allowed.includes("*")) return true;
  return allowed.some((p) => path === p || path.startsWith(p + "/"));
}

export function allowedPaths(role: Role): string[] {
  return roleRoutes[role];
}

interface AuthCtx {
  user: User | null;
  login: (email: string, password: string) => { ok: true } | { ok: false; error: string };
  logout: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);
const STORAGE_KEY = "staynest.auth.user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  const login: AuthCtx["login"] = (email, password) => {
    const match = demoAccounts.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!match) return { ok: false, error: "No account found for that email." };
    if (match.status !== "ACTIVE") return { ok: false, error: "This account is inactive." };
    // Mock: any non-empty password works (demo).
    if (!password) return { ok: false, error: "Password is required." };
    setUser(match);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(match));
    } catch {
      /* ignore */
    }
    return { ok: true };
  };

  const logout = () => {
    setUser(null);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
  };

  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used within AuthProvider");
  return v;
}
