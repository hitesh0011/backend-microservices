// Central mock data for StayNest — Phase 1/2 (no backend yet).

export type Role =
  | "GUEST"
  | "FRONTDESK"
  | "HOUSEKEEPING"
  | "FBMANAGER"
  | "REVENUEMANAGER"
  | "ADMIN";

export interface User {
  id: number;
  name: string;
  role: Role;
  email: string;
  phone: string;
  property: string;
  status: "ACTIVE" | "INACTIVE";
}

export const initialUsers: User[] = [
  { id: 1, name: "Hitesh Paluri", role: "ADMIN", email: "hitesh@staynest.io", phone: "+91 98100 11111", property: "StayNest Bengaluru", status: "ACTIVE" },
  { id: 2, name: "Jigeesha Anagani", role: "FRONTDESK", email: "jigeesha@staynest.io", phone: "+91 98100 22222", property: "StayNest Bengaluru", status: "ACTIVE" },
  { id: 3, name: "Bhanu Prakash", role: "REVENUEMANAGER", email: "bhanu@staynest.io", phone: "+91 98100 33333", property: "StayNest Goa", status: "ACTIVE" },
  { id: 4, name: "Sivaramakrishnan B", role: "FBMANAGER", email: "siva@staynest.io", phone: "+91 98100 44444", property: "StayNest Goa", status: "ACTIVE" },
  { id: 5, name: "Suma Sindhura", role: "HOUSEKEEPING", email: "suma@staynest.io", phone: "+91 98100 55555", property: "StayNest Bengaluru", status: "INACTIVE" },
];

export interface RoomType {
  id: number;
  name: "Standard" | "Deluxe" | "Suite" | "Villa";
  bedConfig: string;
  maxOccupancy: number;
  baseRate: number;
  amenities: string[];
  status: "ACTIVE" | "INACTIVE";
}

export const roomTypes: RoomType[] = [
  { id: 1, name: "Standard", bedConfig: "1 Queen", maxOccupancy: 2, baseRate: 4500, amenities: ["Wi-Fi", "AC", "TV"], status: "ACTIVE" },
  { id: 2, name: "Deluxe", bedConfig: "1 King", maxOccupancy: 3, baseRate: 7200, amenities: ["Wi-Fi", "AC", "TV", "Mini-bar", "City view"], status: "ACTIVE" },
  { id: 3, name: "Suite", bedConfig: "1 King + Sofa", maxOccupancy: 4, baseRate: 12500, amenities: ["Wi-Fi", "AC", "Lounge", "Mini-bar", "Bath tub"], status: "ACTIVE" },
  { id: 4, name: "Villa", bedConfig: "2 King", maxOccupancy: 6, baseRate: 24000, amenities: ["Private pool", "Butler", "Wi-Fi", "Kitchenette"], status: "ACTIVE" },
];

export type RoomStatus = "AVAILABLE" | "OCCUPIED" | "CLEANING" | "MAINTENANCE" | "BLOCKED";
export interface Room {
  id: number;
  number: string;
  floor: number;
  roomTypeId: number;
  status: RoomStatus;
}
export const initialRooms: Room[] = [
  { id: 101, number: "101", floor: 1, roomTypeId: 1, status: "AVAILABLE" },
  { id: 102, number: "102", floor: 1, roomTypeId: 1, status: "OCCUPIED" },
  { id: 201, number: "201", floor: 2, roomTypeId: 2, status: "CLEANING" },
  { id: 202, number: "202", floor: 2, roomTypeId: 2, status: "AVAILABLE" },
  { id: 301, number: "301", floor: 3, roomTypeId: 3, status: "MAINTENANCE" },
  { id: 401, number: "401", floor: 4, roomTypeId: 4, status: "AVAILABLE" },
];

export interface RatePlan {
  id: number;
  roomTypeId: number;
  name: "Rack" | "Corporate" | "Seasonal" | "Promo";
  price: number;
  validFrom: string;
  validTo: string;
  mealPlan: boolean;
  status: "ACTIVE" | "INACTIVE";
}
export const ratePlans: RatePlan[] = [
  { id: 1, roomTypeId: 1, name: "Rack", price: 4500, validFrom: "2026-01-01", validTo: "2026-12-31", mealPlan: false, status: "ACTIVE" },
  { id: 2, roomTypeId: 1, name: "Corporate", price: 3800, validFrom: "2026-01-01", validTo: "2026-12-31", mealPlan: true, status: "ACTIVE" },
  { id: 3, roomTypeId: 2, name: "Seasonal", price: 8500, validFrom: "2026-10-01", validTo: "2027-01-15", mealPlan: true, status: "ACTIVE" },
  { id: 4, roomTypeId: 3, name: "Promo", price: 10500, validFrom: "2026-07-01", validTo: "2026-08-31", mealPlan: true, status: "ACTIVE" },
];

export interface Arrival { reservationId: string; guest: string; roomType: string; nights: number; adults: number; }
export const arrivalsToday: Arrival[] = [
  { reservationId: "RSV-10241", guest: "Priya Menon", roomType: "Deluxe", nights: 3, adults: 2 },
  { reservationId: "RSV-10242", guest: "Rahul Verma", roomType: "Suite", nights: 2, adults: 2 },
  { reservationId: "RSV-10243", guest: "Chen Wei", roomType: "Standard", nights: 1, adults: 1 },
];
export interface Departure { stayId: string; guest: string; room: string; balance: number; }
export const departuresToday: Departure[] = [
  { stayId: "STY-5501", guest: "Anjali Rao", room: "202", balance: 18200 },
  { stayId: "STY-5502", guest: "Marcus Ade", room: "101", balance: 6400 },
];

export type ChargeType = "RoomRent" | "FBCharge" | "LaundryCharge" | "Spa" | "Tax" | "Discount";
export interface FolioItem { id: number; type: ChargeType; description: string; amount: number; postedDate: string; postedBy: string; }
export interface Stay { id: string; guest: string; room: string; roomType: string; checkIn: string; folio: FolioItem[]; status: "ACTIVE" | "CHECKEDOUT"; }
export const stays: Stay[] = [
  {
    id: "STY-5501", guest: "Anjali Rao", room: "202", roomType: "Deluxe", checkIn: "2026-07-22", status: "ACTIVE",
    folio: [
      { id: 1, type: "RoomRent", description: "Deluxe · 2 nights", amount: 14400, postedDate: "2026-07-22", postedBy: "System" },
      { id: 2, type: "FBCharge", description: "In-room dining", amount: 1850, postedDate: "2026-07-23", postedBy: "F&B" },
      { id: 3, type: "Tax", description: "GST 12%", amount: 1950, postedDate: "2026-07-23", postedBy: "System" },
    ],
  },
];

export type TaskStatus = "PENDING" | "INPROGRESS" | "DONE";
export interface HKTask { id: number; room: string; type: "Checkout" | "StayoverService" | "TurnDown" | "DeepClean"; assignedTo: string; status: TaskStatus; }
export const initialTasks: HKTask[] = [
  { id: 1, room: "101", type: "Checkout", assignedTo: "Suma S.", status: "PENDING" },
  { id: 2, room: "202", type: "StayoverService", assignedTo: "Rekha P.", status: "INPROGRESS" },
  { id: 3, room: "301", type: "DeepClean", assignedTo: "Aman K.", status: "PENDING" },
  { id: 4, room: "401", type: "TurnDown", assignedTo: "Rekha P.", status: "DONE" },
];

export type Priority = "LOW" | "MEDIUM" | "HIGH" | "URGENT";
export interface Maintenance { id: number; room: string; issue: string; priority: Priority; raised: string; status: "OPEN" | "INPROGRESS" | "RESOLVED"; }
export const initialMaintenance: Maintenance[] = [
  { id: 1, room: "301", issue: "AC not cooling below 24°C", priority: "HIGH", raised: "2026-07-21", status: "OPEN" },
  { id: 2, room: "102", issue: "Bathroom faucet dripping", priority: "LOW", raised: "2026-07-20", status: "INPROGRESS" },
];

export type MenuCategory = "Breakfast" | "MainCourse" | "Beverage" | "Dessert";
export interface MenuItem { id: number; name: string; category: MenuCategory; price: number; available: boolean; tags: string[]; }
export const initialMenu: MenuItem[] = [
  { id: 1, name: "Masala Dosa", category: "Breakfast", price: 320, available: true, tags: ["Veg"] },
  { id: 2, name: "Butter Chicken", category: "MainCourse", price: 620, available: true, tags: ["Non-veg"] },
  { id: 3, name: "Paneer Tikka", category: "MainCourse", price: 480, available: true, tags: ["Veg"] },
  { id: 4, name: "Fresh Lime Soda", category: "Beverage", price: 180, available: true, tags: ["Vegan"] },
  { id: 5, name: "Gulab Jamun", category: "Dessert", price: 240, available: false, tags: ["Veg"] },
];

export type OrderStatus = "PLACED" | "PREPARING" | "SERVED" | "BILLED" | "CANCELLED";
export interface FBOrder { id: string; type: "DineIn" | "InRoomDining" | "Takeaway"; location: string; items: { name: string; qty: number; price: number }[]; total: number; time: string; status: OrderStatus; }
export const initialOrders: FBOrder[] = [
  { id: "ORD-9001", type: "InRoomDining", location: "Room 202", items: [{ name: "Butter Chicken", qty: 1, price: 620 }, { name: "Fresh Lime Soda", qty: 2, price: 180 }], total: 980, time: "13:20", status: "PREPARING" },
  { id: "ORD-9002", type: "DineIn", location: "Table 5", items: [{ name: "Paneer Tikka", qty: 1, price: 480 }], total: 480, time: "13:45", status: "PLACED" },
];

export interface DiningReservation { id: string; guest: string; outlet: string; date: string; time: string; covers: number; status: "CONFIRMED" | "SEATED" | "COMPLETED" | "CANCELLED"; }
export const initialDining: DiningReservation[] = [
  { id: "DIN-2201", guest: "Priya Menon", outlet: "Coastal Kitchen", date: "2026-07-24", time: "20:00", covers: 2, status: "CONFIRMED" },
  { id: "DIN-2202", guest: "Rahul Verma", outlet: "Sky Lounge", date: "2026-07-24", time: "21:30", covers: 4, status: "SEATED" },
];

export type NotifCategory = "Reservation" | "FrontDesk" | "Housekeeping" | "FB" | "Revenue";
export interface Notification { id: number; message: string; category: NotifCategory; status: "UNREAD" | "READ"; createdAt: string; }
export const initialNotifications: Notification[] = [
  { id: 1, message: "New reservation RSV-10243 confirmed for tonight", category: "Reservation", status: "UNREAD", createdAt: "10 min ago" },
  { id: 2, message: "Room 301 flagged for deep clean before 15:00", category: "Housekeeping", status: "UNREAD", createdAt: "22 min ago" },
  { id: 3, message: "Occupancy crossed 85% threshold — enable Peak rate?", category: "Revenue", status: "UNREAD", createdAt: "1 hr ago" },
  { id: 4, message: "Order ORD-9001 marked SERVED", category: "FB", status: "READ", createdAt: "2 hr ago" },
];

export type LoyaltyTier = "NONE" | "SILVER" | "GOLD" | "PLATINUM";
export interface Reservation { id: string; roomType: string; checkIn: string; checkOut: string; nights: number; total: number; status: "CONFIRMED" | "CHECKEDIN" | "CHECKEDOUT" | "CANCELLED"; }
export const initialReservations: Reservation[] = [
  { id: "RSV-10231", roomType: "Deluxe", checkIn: "2026-06-14", checkOut: "2026-06-17", nights: 3, total: 21600, status: "CHECKEDOUT" },
  { id: "RSV-10240", roomType: "Suite", checkIn: "2026-08-02", checkOut: "2026-08-05", nights: 3, total: 37500, status: "CONFIRMED" },
  { id: "RSV-10241", roomType: "Villa", checkIn: "2026-09-12", checkOut: "2026-09-15", nights: 3, total: 72000, status: "CONFIRMED" },
];
