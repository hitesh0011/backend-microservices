import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const map: Record<string, string> = {
  // room
  AVAILABLE: "bg-success/15 text-success border border-success/30",
  OCCUPIED: "bg-destructive/10 text-destructive border border-destructive/30",
  CLEANING: "bg-warning/15 text-warning-foreground border border-warning/40",
  MAINTENANCE: "bg-muted text-muted-foreground border",
  BLOCKED: "bg-muted text-muted-foreground border",
  // user
  ACTIVE: "bg-success/15 text-success border border-success/30",
  INACTIVE: "bg-muted text-muted-foreground border",
  // reservation
  CONFIRMED: "bg-primary/10 text-primary border border-primary/30",
  CHECKEDIN: "bg-success/15 text-success border border-success/30",
  CHECKEDOUT: "bg-muted text-muted-foreground border",
  CANCELLED: "bg-destructive/10 text-destructive border border-destructive/30",
  NOSHOW: "bg-destructive/10 text-destructive border border-destructive/30",
  // task
  PENDING: "bg-warning/15 text-warning-foreground border border-warning/40",
  INPROGRESS: "bg-primary/10 text-primary border border-primary/30",
  DONE: "bg-success/15 text-success border border-success/30",
  // priority
  LOW: "bg-muted text-muted-foreground border",
  MEDIUM: "bg-primary/10 text-primary border border-primary/30",
  HIGH: "bg-warning/15 text-warning-foreground border border-warning/40",
  URGENT: "bg-destructive/10 text-destructive border border-destructive/30",
  // orders
  PLACED: "bg-primary/10 text-primary border border-primary/30",
  PREPARING: "bg-warning/15 text-warning-foreground border border-warning/40",
  SERVED: "bg-success/15 text-success border border-success/30",
  BILLED: "bg-muted text-muted-foreground border",
  SEATED: "bg-primary/10 text-primary border border-primary/30",
  COMPLETED: "bg-muted text-muted-foreground border",
  // maintenance
  OPEN: "bg-warning/15 text-warning-foreground border border-warning/40",
  RESOLVED: "bg-success/15 text-success border border-success/30",
  // loyalty
  NONE: "bg-muted text-muted-foreground border",
  SILVER: "bg-slate-200 text-slate-800 border border-slate-300",
  GOLD: "bg-[color:var(--gold)]/15 text-[color:var(--gold)] border border-[color:var(--gold)]/40",
  PLATINUM: "bg-fuchsia-100 text-fuchsia-800 border border-fuchsia-200",
  // role
  ADMIN: "bg-primary/10 text-primary border border-primary/30",
  FRONTDESK: "bg-sky-100 text-sky-800 border border-sky-200",
  HOUSEKEEPING: "bg-emerald-100 text-emerald-800 border border-emerald-200",
  FBMANAGER: "bg-amber-100 text-amber-800 border border-amber-200",
  REVENUEMANAGER: "bg-violet-100 text-violet-800 border border-violet-200",
  GUEST: "bg-muted text-muted-foreground border",
};

export function StatusBadge({ value, className }: { value: string; className?: string }) {
  const key = value.toUpperCase().replace(/[\s_-]/g, "");
  const cls = map[key] ?? "bg-muted text-muted-foreground border";
  return (
    <Badge variant="outline" className={cn("rounded-md font-medium tracking-wide", cls, className)}>
      {value}
    </Badge>
  );
}
