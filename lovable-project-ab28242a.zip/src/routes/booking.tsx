import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { roomTypes, ratePlans } from "@/lib/mock-data";
import { toast } from "sonner";
import { Users2, BedDouble, Sparkles, Search } from "lucide-react";

export const Route = createFileRoute("/booking")({
  head: () => ({
    meta: [
      { title: "Book a Stay — StayNest" },
      { name: "description", content: "Search availability and book your next stay with StayNest." },
      { property: "og:title", content: "Book a Stay — StayNest" },
      { property: "og:description", content: "Discover rooms and book instantly." },
    ],
  }),
  component: BookingPage,
});

function BookingPage() {
  const today = new Date().toISOString().slice(0, 10);
  const tmr = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const [checkIn, setCheckIn] = useState(today);
  const [checkOut, setCheckOut] = useState(tmr);
  const [adults, setAdults] = useState("2");
  const [children, setChildren] = useState("0");
  const [selected, setSelected] = useState<number | null>(null);
  const [rateId, setRateId] = useState<string>("");

  const nights = Math.max(
    1,
    Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000),
  );
  const room = roomTypes.find((r) => r.id === selected);
  const applicableRates = useMemo(
    () => selected ? ratePlans.filter((r) => r.roomTypeId === selected) : [],
    [selected],
  );
  const chosenRate = applicableRates.find((r) => String(r.id) === rateId);
  const total = chosenRate ? chosenRate.price * nights : room ? room.baseRate * nights : 0;

  return (
    <>
      <PageHeader title="Book a Stay" description="Find the perfect room for your dates" />
      <Card className="mb-6">
        <CardContent className="p-5">
          <div className="grid gap-3 md:grid-cols-5">
            <div><Label className="text-xs">Check-in</Label><Input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} /></div>
            <div><Label className="text-xs">Check-out</Label><Input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} /></div>
            <div><Label className="text-xs">Adults</Label><Input type="number" min={1} value={adults} onChange={(e) => setAdults(e.target.value)} /></div>
            <div><Label className="text-xs">Children</Label><Input type="number" min={0} value={children} onChange={(e) => setChildren(e.target.value)} /></div>
            <div className="flex items-end"><Button className="w-full"><Search className="mr-1.5 h-4 w-4" /> Search</Button></div>
          </div>
          <div className="mt-2 text-xs text-muted-foreground">{nights} nights · {adults} adults · {children} children</div>
        </CardContent>
      </Card>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {roomTypes.map((r) => (
          <Card key={r.id} className="overflow-hidden">
            <div className="relative h-40 bg-gradient-to-br from-primary/25 via-[color:var(--gold)]/25 to-accent">
              <div className="absolute inset-0 flex items-end p-4">
                <span className="rounded-md bg-background/85 px-2 py-1 text-xs font-medium backdrop-blur">{r.name}</span>
              </div>
            </div>
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <h3 className="font-serif text-xl">{r.name}</h3>
                <div className="text-right">
                  <div className="font-serif text-xl">₹{r.baseRate.toLocaleString()}</div>
                  <div className="text-[10px] uppercase text-muted-foreground">per night</div>
                </div>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{r.bedConfig}</p>
              <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Users2 className="h-3.5 w-3.5" /> up to {r.maxOccupancy}</span>
                <span className="flex items-center gap-1"><BedDouble className="h-3.5 w-3.5" /> {r.bedConfig.split(" ")[0]}</span>
                <span className="flex items-center gap-1"><Sparkles className="h-3.5 w-3.5" /> {r.amenities.length} amenities</span>
              </div>
              <div className="mt-3 flex flex-wrap gap-1">
                {r.amenities.slice(0, 3).map((a) => (
                  <Badge key={a} variant="secondary" className="rounded-md font-normal">{a}</Badge>
                ))}
              </div>
              <Button
                className="mt-4 w-full"
                onClick={() => { setSelected(r.id); setRateId(""); }}
              >
                Book now
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Confirm booking · {room?.name}</DialogTitle></DialogHeader>
          <div className="grid gap-3">
            <div className="rounded-md border p-3 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Check-in</span><span>{checkIn}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Check-out</span><span>{checkOut}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Nights</span><span>{nights}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Guests</span><span>{adults} adults · {children} children</span></div>
            </div>
            <div>
              <Label>Rate plan</Label>
              <Select value={rateId} onValueChange={setRateId}>
                <SelectTrigger><SelectValue placeholder={`Base rate · ₹${room?.baseRate}`} /></SelectTrigger>
                <SelectContent>
                  {applicableRates.map((r) => (
                    <SelectItem key={r.id} value={String(r.id)}>{r.name} · ₹{r.price} {r.mealPlan ? "· incl. breakfast" : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-md bg-secondary/60 p-3 text-right">
              <div className="text-xs text-muted-foreground">Total</div>
              <div className="font-serif text-2xl">₹{total.toLocaleString()}</div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelected(null)}>Cancel</Button>
            <Button onClick={() => { toast.success("Reservation confirmed"); setSelected(null); }}>
              Confirm booking
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
