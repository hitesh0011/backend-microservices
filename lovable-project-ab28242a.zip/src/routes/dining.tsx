import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { initialDining } from "@/lib/mock-data";

export const Route = createFileRoute("/dining")({
  head: () => ({
    meta: [
      { title: "Dining Reservations — StayNest" },
      { name: "description", content: "Table reservations across restaurant outlets." },
      { property: "og:title", content: "Dining Reservations — StayNest" },
      { property: "og:description", content: "Manage outlet reservations." },
    ],
  }),
  component: DiningPage,
});

function DiningPage() {
  const [date, setDate] = useState("");
  const filtered = useMemo(() => date ? initialDining.filter((d) => d.date === date) : initialDining, [date]);
  return (
    <>
      <PageHeader title="Dining Reservations" description="Table bookings across outlets" actions={<Button>New reservation</Button>} />
      <Card>
        <CardContent className="p-4">
          <div className="mb-3 flex items-end gap-3">
            <div>
              <Label className="text-xs">Filter by date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-48" />
            </div>
            {date && <Button variant="ghost" size="sm" onClick={() => setDate("")}>Clear</Button>}
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead><TableHead>Guest</TableHead><TableHead>Outlet</TableHead>
                <TableHead>Date</TableHead><TableHead>Time</TableHead>
                <TableHead>Covers</TableHead><TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="font-mono text-xs">{d.id}</TableCell>
                  <TableCell className="font-medium">{d.guest}</TableCell>
                  <TableCell>{d.outlet}</TableCell>
                  <TableCell className="text-muted-foreground">{d.date}</TableCell>
                  <TableCell>{d.time}</TableCell>
                  <TableCell>{d.covers}</TableCell>
                  <TableCell><StatusBadge value={d.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
