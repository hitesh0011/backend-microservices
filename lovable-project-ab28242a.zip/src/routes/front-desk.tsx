import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { arrivalsToday, departuresToday, initialRooms } from "@/lib/mock-data";
import { StatusBadge } from "@/lib/status-badges";
import { toast } from "sonner";

export const Route = createFileRoute("/front-desk")({
  head: () => ({
    meta: [
      { title: "Front Desk — StayNest" },
      { name: "description", content: "Arrivals, departures and room assignment for the front desk team." },
      { property: "og:title", content: "Front Desk — StayNest" },
      { property: "og:description", content: "Handle check-ins and departures in one console." },
    ],
  }),
  component: FrontDeskPage,
});

function FrontDeskPage() {
  const [arrivals, setArrivals] = useState(arrivalsToday);
  const [assignFor, setAssignFor] = useState<string | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<string>("");
  const available = initialRooms.filter((r) => r.status === "AVAILABLE");

  return (
    <>
      <PageHeader
        title="Front Desk"
        description="Arrivals, departures, and room assignments"
        actions={<Button variant="outline">Walk-in booking</Button>}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardContent className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-serif text-xl">Arrivals today</h2>
              <span className="text-xs text-muted-foreground">{arrivals.length} expected</span>
            </div>
            <ul className="divide-y">
              {arrivals.map((a) => (
                <li key={a.reservationId} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div>
                    <div className="font-medium">{a.guest}</div>
                    <div className="text-xs text-muted-foreground">
                      {a.reservationId} · {a.roomType} · {a.nights}N · {a.adults} adults
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge value="CONFIRMED" />
                    <Button size="sm" onClick={() => { setAssignFor(a.reservationId); setSelectedRoom(""); }}>
                      Check-in
                    </Button>
                  </div>
                </li>
              ))}
              {arrivals.length === 0 && (
                <li className="py-8 text-center text-sm text-muted-foreground">All checked in.</li>
              )}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-serif text-xl">Departures today</h2>
              <span className="text-xs text-muted-foreground">{departuresToday.length} pending</span>
            </div>
            <ul className="divide-y">
              {departuresToday.map((d) => (
                <li key={d.stayId} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div>
                    <div className="font-medium">{d.guest}</div>
                    <div className="text-xs text-muted-foreground">Room {d.room} · {d.stayId}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="font-semibold">₹{d.balance.toLocaleString()}</div>
                      <div className="text-[10px] uppercase text-muted-foreground">folio</div>
                    </div>
                    <Link to="/stays/$stayId" params={{ stayId: d.stayId }}>
                      <Button size="sm" variant="outline">Open folio</Button>
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!assignFor} onOpenChange={(o) => !o && setAssignFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Assign room · {assignFor}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="text-sm text-muted-foreground">Select from available rooms</div>
            <Select value={selectedRoom} onValueChange={setSelectedRoom}>
              <SelectTrigger><SelectValue placeholder="Choose room…" /></SelectTrigger>
              <SelectContent>
                {available.map((r) => (
                  <SelectItem key={r.id} value={r.number}>Room {r.number} · Floor {r.floor}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignFor(null)}>Cancel</Button>
            <Button
              disabled={!selectedRoom}
              onClick={() => {
                setArrivals((cur) => cur.filter((a) => a.reservationId !== assignFor));
                toast.success(`Checked in to room ${selectedRoom}`);
                setAssignFor(null);
              }}
            >
              Confirm check-in
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
