import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { initialTasks, type HKTask, type TaskStatus } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/housekeeping")({
  head: () => ({
    meta: [
      { title: "Housekeeping — StayNest" },
      { name: "description", content: "Daily housekeeping task board for room readiness and turn-down service." },
      { property: "og:title", content: "Housekeeping — StayNest" },
      { property: "og:description", content: "Track cleaning tasks across floors." },
    ],
  }),
  component: HousekeepingPage,
});

const columns: { key: TaskStatus; label: string }[] = [
  { key: "PENDING", label: "Pending" },
  { key: "INPROGRESS", label: "In progress" },
  { key: "DONE", label: "Done" },
];

function next(s: TaskStatus): TaskStatus {
  return s === "PENDING" ? "INPROGRESS" : s === "INPROGRESS" ? "DONE" : "DONE";
}

function HousekeepingPage() {
  const [tasks, setTasks] = useState<HKTask[]>(initialTasks);
  return (
    <>
      <PageHeader
        title="Housekeeping"
        description="Task board across all floors — click a card to advance it"
        actions={<Button>New task</Button>}
      />
      <div className="grid gap-4 md:grid-cols-3">
        {columns.map((col) => {
          const list = tasks.filter((t) => t.status === col.key);
          return (
            <div key={col.key} className="rounded-lg border bg-secondary/40 p-3">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-serif text-lg">{col.label}</span>
                  <span className="rounded-full bg-background px-2 py-0.5 text-xs">{list.length}</span>
                </div>
              </div>
              <div className="space-y-2">
                {list.map((t) => (
                  <Card key={t.id} className="border-border/70">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="font-semibold">Room {t.room}</div>
                        <StatusBadge value={t.type} />
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">Assigned · {t.assignedTo}</div>
                      {t.status !== "DONE" && (
                        <Button
                          size="sm" variant="outline" className="mt-3 w-full"
                          onClick={() => {
                            setTasks((cur) => cur.map((x) => x.id === t.id ? { ...x, status: next(x.status) } : x));
                            toast.success(`Room ${t.room} → ${next(t.status)}`);
                          }}
                        >
                          Move to {next(t.status)}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
                {list.length === 0 && (
                  <div className="rounded-md border border-dashed p-6 text-center text-xs text-muted-foreground">
                    No tasks
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
