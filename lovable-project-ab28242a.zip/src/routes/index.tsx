import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/AppShell";
import { arrivalsToday, departuresToday } from "@/lib/mock-data";
import { StatusBadge } from "@/lib/status-badges";
import { ArrowUpRight, TrendingUp, Users2, BedDouble, Star } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Revenue Dashboard — StayNest" },
      { name: "description", content: "Occupancy, ADR, RevPAR and guest satisfaction across your properties." },
      { property: "og:title", content: "Revenue Dashboard — StayNest" },
      { property: "og:description", content: "Live hospitality KPIs at a glance." },
    ],
  }),
  component: Dashboard,
});

const kpis = [
  { label: "Occupancy", value: "78%", trend: "+4.2%", progress: 78, icon: BedDouble },
  { label: "ADR", value: "₹4,500", trend: "+1.8%", progress: 62, icon: TrendingUp },
  { label: "RevPAR", value: "₹3,510", trend: "+3.1%", progress: 55, icon: ArrowUpRight },
  { label: "Guest Score", value: "4.2 / 5", trend: "+0.1", progress: 84, icon: Star },
];

const rateSplit = [
  { name: "Rack", pct: 42 },
  { name: "Corporate", pct: 28 },
  { name: "Seasonal", pct: 18 },
  { name: "Promo", pct: 12 },
];

function Dashboard() {
  return (
    <>
      <PageHeader
        title="Revenue Dashboard"
        description="Property performance across StayNest Bengaluru & StayNest Goa"
        actions={
          <>
            <Button variant="outline">Export</Button>
            <Button>Generate report</Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((k) => (
          <Card key={k.label} className="border-border/70">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">
                    {k.label}
                  </div>
                  <div className="mt-1 font-serif text-3xl">{k.value}</div>
                </div>
                <div className="rounded-md bg-primary/10 p-2 text-primary">
                  <k.icon className="h-4 w-4" />
                </div>
              </div>
              <Progress value={k.progress} className="mt-4 h-1.5" />
              <div className="mt-2 text-xs text-success">{k.trend} vs last week</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-serif text-xl">Occupancy heat · last 14 days</h2>
              <span className="text-xs text-muted-foreground">peak Fri–Sat</span>
            </div>
            <div className="grid grid-cols-14 gap-1.5" style={{ gridTemplateColumns: "repeat(14, minmax(0, 1fr))" }}>
              {Array.from({ length: 14 }).map((_, i) => {
                const val = [42, 55, 61, 58, 66, 78, 92, 88, 63, 70, 74, 81, 90, 95][i];
                return (
                  <div key={i} className="flex flex-col items-center gap-1.5">
                    <div
                      className="w-full rounded-sm"
                      style={{
                        height: 96,
                        background: `linear-gradient(180deg, transparent ${100 - val}%, oklch(0.55 0.12 155 / 0.9) ${100 - val}%)`,
                      }}
                    />
                    <span className="text-[10px] text-muted-foreground">{i + 10}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="font-serif text-xl">Rate plan performance</h2>
            <div className="mt-4 space-y-3">
              {rateSplit.map((r) => (
                <div key={r.name}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span>{r.name}</span>
                    <span className="text-muted-foreground">{r.pct}%</span>
                  </div>
                  <Progress value={r.pct} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardContent className="p-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-serif text-xl flex items-center gap-2">
                <Users2 className="h-5 w-5 text-primary" /> Arrivals today
              </h2>
              <Link to="/front-desk" className="text-xs text-primary hover:underline">
                Open front desk →
              </Link>
            </div>
            <ul className="divide-y">
              {arrivalsToday.map((a) => (
                <li key={a.reservationId} className="flex items-center justify-between py-2.5">
                  <div>
                    <div className="font-medium">{a.guest}</div>
                    <div className="text-xs text-muted-foreground">
                      {a.reservationId} · {a.roomType} · {a.nights} nights
                    </div>
                  </div>
                  <StatusBadge value="CONFIRMED" />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h2 className="font-serif text-xl mb-3">Departures today</h2>
            <ul className="divide-y">
              {departuresToday.map((d) => (
                <li key={d.stayId} className="flex items-center justify-between py-2.5">
                  <div>
                    <div className="font-medium">{d.guest}</div>
                    <div className="text-xs text-muted-foreground">Room {d.room} · {d.stayId}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">₹{d.balance.toLocaleString()}</div>
                    <div className="text-xs text-muted-foreground">folio balance</div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
