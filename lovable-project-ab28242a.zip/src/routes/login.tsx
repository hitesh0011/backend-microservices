import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Hotel } from "lucide-react";
import { toast } from "sonner";
import { demoAccounts, useAuth } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — StayNest" },
      { name: "description", content: "Sign in to StayNest hospitality operations." },
      { property: "og:title", content: "Sign in — StayNest" },
      { property: "og:description", content: "Front desk, housekeeping, F&B and revenue tools." },
    ],
  }),
  component: LoginPage,
});

const roleHome: Record<string, string> = {
  ADMIN: "/",
  FRONTDESK: "/front-desk",
  HOUSEKEEPING: "/housekeeping",
  FBMANAGER: "/orders",
  REVENUEMANAGER: "/",
  GUEST: "/booking",
};

function LoginPage() {
  const navigate = useNavigate();
  const { user, login } = useAuth();
  const [email, setEmail] = useState("jigeesha@staynest.io");
  const [password, setPassword] = useState("demo");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) navigate({ to: roleHome[user.role] ?? "/" });
  }, [user, navigate]);

  return (
    <div className="grid min-h-screen bg-background md:grid-cols-2">
      <div className="hidden md:flex relative flex-col justify-between overflow-hidden bg-primary text-primary-foreground p-10">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-md bg-[color:var(--gold)]/25 text-[color:var(--gold)]">
            <Hotel className="h-5 w-5" />
          </div>
          <span className="font-serif text-2xl">StayNest</span>
        </div>
        <div className="relative">
          <h2 className="font-serif text-4xl leading-tight">
            Every stay,<br />flawlessly orchestrated.
          </h2>
          <p className="mt-4 max-w-md text-primary-foreground/80">
            One platform for reservations, front desk, housekeeping, F&B and revenue —
            built for hospitality teams that refuse to compromise.
          </p>
        </div>
        <div className="text-xs text-primary-foreground/60">
          © 2026 StayNest Hospitality · v1.0
        </div>
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-[color:var(--gold)]/15 blur-3xl" />
      </div>

      <div className="flex items-center justify-center p-8">
        <Card className="w-full max-w-md border-border/70 shadow-sm">
          <CardContent className="p-8">
            <h1 className="font-serif text-2xl">Welcome back</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in to continue to your dashboard.
            </p>
            <form
              className="mt-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                setError(null);
                const res = login(email, password);
                if (!res.ok) {
                  setError(res.error);
                  return;
                }
                toast.success("Signed in");
              }}
            >
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  className="mt-1.5"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <span className="text-xs text-muted-foreground">Any password works (demo)</span>
                </div>
                <Input
                  id="password"
                  type="password"
                  className="mt-1.5"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error && (
                <div className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                  {error}
                </div>
              )}
              <Button type="submit" className="w-full">
                Sign in
              </Button>
            </form>

            <div className="mt-6 rounded-md border bg-muted/30 p-3">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                Demo accounts — click to sign in
              </div>
              <div className="mt-2 grid gap-1">
                {demoAccounts.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => {
                      setEmail(u.email);
                      setPassword("demo");
                      setError(null);
                      const res = login(u.email, "demo");
                      if (!res.ok) setError(res.error);
                      else toast.success(`Signed in as ${u.name}`);
                    }}
                    className="flex items-center justify-between rounded px-2 py-1.5 text-left text-xs hover:bg-background"
                  >
                    <span className="font-medium">{u.name}</span>
                    <span className="text-muted-foreground">{u.role}</span>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
