import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { StatusBadge } from "@/lib/status-badges";
import { initialMaintenance, type Priority } from "@/lib/mock-data";
import { toast } from "sonner";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/maintenance")({
  head: () => ({
    meta: [
      { title: "Maintenance — StayNest" },
      { name: "description", content: "Track and resolve maintenance requests across rooms." },
      { property: "og:title", content: "Maintenance — StayNest" },
      { property: "og:description", content: "Room maintenance work orders." },
    ],
  }),
  component: MaintenancePage,
});

const priorities: Priority[] = ["LOW", "MEDIUM", "HIGH", "URGENT"];

function MaintenancePage() {
  const [items, setItems] = useState(initialMaintenance);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ room: string; issue: string; priority: Priority }>({
    room: "", issue: "", priority: "MEDIUM",
  });

  return (
    <>
      <PageHeader
        title="Maintenance"
        description="Open work orders across floors"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-1.5 h-4 w-4" /> Report issue</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Report maintenance issue</DialogTitle></DialogHeader>
              <div className="grid gap-3">
                <div><Label>Room</Label><Input value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} /></div>
                <div><Label>Issue</Label><Input value={form.issue} onChange={(e) => setForm({ ...form, issue: e.target.value })} /></div>
                <div>
                  <Label>Priority</Label>
                  <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v as Priority })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{priorities.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={() => {
                  if (!form.room || !form.issue) { toast.error("Room & issue required"); return; }
                  setItems((cur) => [{
                    id: cur.length + 1, room: form.room, issue: form.issue, priority: form.priority,
                    raised: new Date().toISOString().slice(0, 10), status: "OPEN",
                  }, ...cur]);
                  toast.success("Issue reported");
                  setForm({ room: "", issue: "", priority: "MEDIUM" });
                  setOpen(false);
                }}>Report</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card>
        <CardContent className="p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead><TableHead>Room</TableHead><TableHead>Issue</TableHead>
                <TableHead>Priority</TableHead><TableHead>Raised</TableHead>
                <TableHead>Status</TableHead><TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((m) => (
                <TableRow key={m.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">MNT-{m.id.toString().padStart(4, "0")}</TableCell>
                  <TableCell className="font-semibold">Room {m.room}</TableCell>
                  <TableCell>{m.issue}</TableCell>
                  <TableCell><StatusBadge value={m.priority} /></TableCell>
                  <TableCell className="text-xs text-muted-foreground">{m.raised}</TableCell>
                  <TableCell><StatusBadge value={m.status} /></TableCell>
                  <TableCell className="text-right">
                    {m.status !== "RESOLVED" ? (
                      <Button variant="outline" size="sm" onClick={() => {
                        setItems((cur) => cur.map((x) => x.id === m.id ? { ...x, status: "RESOLVED" } : x));
                        toast.success("Marked resolved");
                      }}>Resolve</Button>
                    ) : <span className="text-xs text-muted-foreground">Closed</span>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
