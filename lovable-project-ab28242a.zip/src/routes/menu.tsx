import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { initialMenu, type MenuCategory, type MenuItem } from "@/lib/mock-data";
import { toast } from "sonner";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "F&B Menu — StayNest" },
      { name: "description", content: "Build and manage menu items across restaurant outlets." },
      { property: "og:title", content: "F&B Menu — StayNest" },
      { property: "og:description", content: "Menu items, categories and availability." },
    ],
  }),
  component: MenuPage,
});

const categories: MenuCategory[] = ["Breakfast", "MainCourse", "Beverage", "Dessert"];

function MenuPage() {
  const [items, setItems] = useState<MenuItem[]>(initialMenu);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<{ name: string; category: MenuCategory; price: string; tags: string }>({
    name: "", category: "MainCourse", price: "", tags: "Veg",
  });

  return (
    <>
      <PageHeader
        title="Menu"
        description="Restaurant menu items across outlets"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-1.5 h-4 w-4" /> Add item</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New menu item</DialogTitle></DialogHeader>
              <div className="grid gap-3">
                <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div>
                  <Label>Category</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v as MenuCategory })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Price (₹)</Label><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
                <div><Label>Dietary tags (comma separated)</Label><Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={() => {
                  if (!form.name || !Number(form.price)) { toast.error("Name & price required"); return; }
                  setItems((cur) => [...cur, {
                    id: cur.length + 1, name: form.name, category: form.category, price: Number(form.price),
                    available: true, tags: form.tags.split(",").map((s) => s.trim()).filter(Boolean),
                  }]);
                  toast.success("Item added");
                  setForm({ name: "", category: "MainCourse", price: "", tags: "Veg" });
                  setOpen(false);
                }}>Add</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />
      {categories.map((cat) => {
        const list = items.filter((i) => i.category === cat);
        if (!list.length) return null;
        return (
          <section key={cat} className="mb-8">
            <div className="mb-3 flex items-baseline gap-3">
              <h2 className="font-serif text-xl">{cat}</h2>
              <span className="text-xs text-muted-foreground">{list.length} items</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((item) => (
                <Card key={item.id} className={item.available ? "" : "opacity-60"}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="mt-0.5 text-xs text-muted-foreground">
                          {item.tags.map((t) => <Badge key={t} variant="secondary" className="mr-1 rounded-md font-normal">{t}</Badge>)}
                        </div>
                      </div>
                      <div className="font-serif text-lg">₹{item.price}</div>
                    </div>
                    <div className="mt-4 flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Available</span>
                      <Switch
                        checked={item.available}
                        onCheckedChange={(v) => {
                          setItems((cur) => cur.map((x) => x.id === item.id ? { ...x, available: v } : x));
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        );
      })}
    </>
  );
}
