import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { initialNotifications, type NotifCategory, type Notification } from "@/lib/mock-data";
import { CheckCheck } from "lucide-react";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Notifications — StayNest" },
      { name: "description", content: "Reservation, front desk, housekeeping, F&B and revenue alerts." },
      { property: "og:title", content: "Notifications — StayNest" },
      { property: "og:description", content: "In-app alerts across modules." },
    ],
  }),
  component: NotificationsPage,
});

const filters: (NotifCategory | "All")[] = ["All", "Reservation", "FrontDesk", "Housekeeping", "FB", "Revenue"];

function NotificationsPage() {
  const [items, setItems] = useState<Notification[]>(initialNotifications);
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const filtered = useMemo(
    () => filter === "All" ? items : items.filter((i) => i.category === filter),
    [items, filter],
  );
  return (
    <>
      <PageHeader
        title="Notifications"
        description="Alerts across reservations, operations and revenue"
        actions={
          <Button variant="outline" onClick={() => setItems((cur) => cur.map((x) => ({ ...x, status: "READ" })))}>
            <CheckCheck className="mr-1.5 h-4 w-4" /> Mark all read
          </Button>
        }
      />
      <Tabs value={filter} onValueChange={(v) => setFilter(v as (typeof filters)[number])}>
        <TabsList>{filters.map((f) => <TabsTrigger key={f} value={f}>{f}</TabsTrigger>)}</TabsList>
      </Tabs>

      <Card className="mt-4">
        <CardContent className="p-0">
          <ul className="divide-y">
            {filtered.map((n) => (
              <li key={n.id} className="flex items-start justify-between gap-4 p-4">
                <div className="flex gap-3">
                  <div className={`mt-1 h-2 w-2 shrink-0 rounded-full ${n.status === "UNREAD" ? "bg-primary" : "bg-muted-foreground/40"}`} />
                  <div>
                    <div className={n.status === "UNREAD" ? "font-medium" : "text-muted-foreground"}>{n.message}</div>
                    <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                      <Badge variant="secondary" className="rounded-md font-normal">{n.category}</Badge>
                      <span>{n.createdAt}</span>
                    </div>
                  </div>
                </div>
                {n.status === "UNREAD" && (
                  <Button variant="ghost" size="sm" onClick={() => {
                    setItems((cur) => cur.map((x) => x.id === n.id ? { ...x, status: "READ" } : x));
                  }}>Mark read</Button>
                )}
              </li>
            ))}
            {filtered.length === 0 && (
              <li className="p-10 text-center text-sm text-muted-foreground">No notifications in this category.</li>
            )}
          </ul>
        </CardContent>
      </Card>
    </>
  );
}
