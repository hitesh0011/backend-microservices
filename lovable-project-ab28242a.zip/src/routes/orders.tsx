import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { initialOrders, type OrderStatus, type FBOrder } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/orders")({
  head: () => ({
    meta: [
      { title: "F&B Orders — StayNest" },
      { name: "description", content: "Active orders across dining, in-room and takeaway." },
      { property: "og:title", content: "F&B Orders — StayNest" },
      { property: "og:description", content: "Track and progress F&B orders." },
    ],
  }),
  component: OrdersPage,
});

function nextStatus(s: OrderStatus): OrderStatus | null {
  const flow: OrderStatus[] = ["PLACED", "PREPARING", "SERVED", "BILLED"];
  const idx = flow.indexOf(s);
  return idx >= 0 && idx < flow.length - 1 ? flow[idx + 1] : null;
}

function OrdersPage() {
  const [orders, setOrders] = useState<FBOrder[]>(initialOrders);
  return (
    <>
      <PageHeader title="Active Orders" description="Point-of-sale, in-room dining and takeaway" />
      <Card>
        <CardContent className="p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead><TableHead>Type</TableHead><TableHead>Location</TableHead>
                <TableHead>Items</TableHead><TableHead>Total</TableHead>
                <TableHead>Status</TableHead><TableHead className="text-right">Advance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((o) => {
                const nxt = nextStatus(o.status);
                return (
                  <TableRow key={o.id}>
                    <TableCell className="font-mono text-xs">{o.id}</TableCell>
                    <TableCell><StatusBadge value={o.type} /></TableCell>
                    <TableCell className="text-muted-foreground">{o.location}</TableCell>
                    <TableCell className="text-xs">
                      {o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}
                    </TableCell>
                    <TableCell className="font-semibold">₹{o.total.toLocaleString()}</TableCell>
                    <TableCell><StatusBadge value={o.status} /></TableCell>
                    <TableCell className="text-right space-x-2">
                      {nxt && (
                        <Button size="sm" variant="outline" onClick={() => {
                          setOrders((cur) => cur.map((x) => x.id === o.id ? { ...x, status: nxt } : x));
                          toast.success(`${o.id} → ${nxt}`);
                        }}>Mark {nxt}</Button>
                      )}
                      {o.status === "PLACED" && (
                        <Button size="sm" variant="ghost" onClick={() => {
                          setOrders((cur) => cur.map((x) => x.id === o.id ? { ...x, status: "CANCELLED" } : x));
                          toast.success("Order cancelled");
                        }}>Cancel</Button>
                      )}
                      {o.status !== "PLACED" && !nxt && (
                        <span className="text-xs text-muted-foreground">Complete</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
