import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/lib/status-badges";
import type { LoyaltyTier } from "@/lib/mock-data";
import { toast } from "sonner";
import { Award } from "lucide-react";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Guest Profile — StayNest" },
      { name: "description", content: "Manage your profile, preferences and loyalty tier." },
      { property: "og:title", content: "Guest Profile — StayNest" },
      { property: "og:description", content: "Preferences and loyalty status." },
    ],
  }),
  component: ProfilePage,
});

const tiers: LoyaltyTier[] = ["NONE", "SILVER", "GOLD", "PLATINUM"];

function ProfilePage() {
  const [profile, setProfile] = useState({
    name: "Priya Menon",
    email: "priya.menon@example.com",
    phone: "+91 98450 12345",
    nationality: "Indian",
    tier: "GOLD" as LoyaltyTier,
    preferences: "High floor, quiet room, extra pillows, oat milk",
  });

  return (
    <>
      <PageHeader title="Guest Profile" description="Your profile and stay preferences" />
      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-primary text-primary-foreground font-serif text-2xl">
              {profile.name.split(" ").map((n) => n[0]).join("")}
            </div>
            <h2 className="mt-3 font-serif text-2xl">{profile.name}</h2>
            <p className="text-sm text-muted-foreground">{profile.email}</p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <Award className="h-4 w-4 text-[color:var(--gold)]" />
              <StatusBadge value={profile.tier} />
            </div>
            <div className="mt-6 rounded-md border p-4 text-left">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Lifetime</div>
              <div className="mt-2 flex justify-between text-sm"><span>Stays</span><span className="font-semibold">18</span></div>
              <div className="mt-1 flex justify-between text-sm"><span>Nights</span><span className="font-semibold">42</span></div>
              <div className="mt-1 flex justify-between text-sm"><span>Points</span><span className="font-semibold">3,240</span></div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="font-serif text-xl">Edit profile</h3>
            <form
              className="mt-4 grid gap-4 sm:grid-cols-2"
              onSubmit={(e) => { e.preventDefault(); toast.success("Profile updated"); }}
            >
              <div><Label>Full name</Label><Input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} /></div>
              <div><Label>Email</Label><Input type="email" value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} /></div>
              <div><Label>Nationality</Label><Input value={profile.nationality} onChange={(e) => setProfile({ ...profile, nationality: e.target.value })} /></div>
              <div className="sm:col-span-2">
                <Label>Loyalty tier</Label>
                <Select value={profile.tier} onValueChange={(v) => setProfile({ ...profile, tier: v as LoyaltyTier })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{tiers.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2">
                <Label>Preferences</Label>
                <Textarea rows={4} value={profile.preferences} onChange={(e) => setProfile({ ...profile, preferences: e.target.value })} />
              </div>
              <div className="sm:col-span-2 flex justify-end">
                <Button type="submit">Save changes</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
