import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { StatusBadge } from "@/lib/status-badges";
import { ratePlans, roomTypes } from "@/lib/mock-data";

export const Route = createFileRoute("/rate-plans")({
  head: () => ({
    meta: [
      { title: "Rate Plans — StayNest" },
      { name: "description", content: "Rack, corporate, seasonal and promo tariffs per room type." },
      { property: "og:title", content: "Rate Plans — StayNest" },
      { property: "og:description", content: "Manage tariffs and meal plan inclusions." },
    ],
  }),
  component: RatePlansPage,
});

function RatePlansPage() {
  const [typeId, setTypeId] = useState<string>("all");
  const filtered = useMemo(
    () => typeId === "all" ? ratePlans : ratePlans.filter((r) => r.roomTypeId === Number(typeId)),
    [typeId],
  );
  return (
    <>
      <PageHeader title="Rate Plans" description="Tariff schedule with meal plan inclusions" actions={<Button>New rate plan</Button>} />
      <Card>
        <CardContent className="p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Room type</span>
            <Select value={typeId} onValueChange={setTypeId}>
              <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {roomTypes.map((t) => <SelectItem key={t.id} value={String(t.id)}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Plan</TableHead><TableHead>Room type</TableHead><TableHead>Price / night</TableHead>
                <TableHead>Valid</TableHead><TableHead>Meal plan</TableHead><TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>{roomTypes.find((t) => t.id === p.roomTypeId)?.name}</TableCell>
                  <TableCell className="font-semibold">₹{p.price.toLocaleString()}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{p.validFrom} → {p.validTo}</TableCell>
                  <TableCell><Switch checked={p.mealPlan} /></TableCell>
                  <TableCell><StatusBadge value={p.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
