import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { initialReservations, type Reservation } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/reservations")({
  head: () => ({
    meta: [
      { title: "My Reservations — StayNest" },
      { name: "description", content: "Upcoming and past stays for your StayNest account." },
      { property: "og:title", content: "My Reservations — StayNest" },
      { property: "og:description", content: "Manage your stays." },
    ],
  }),
  component: ReservationsPage,
});

function ReservationsPage() {
  const [items, setItems] = useState<Reservation[]>(initialReservations);
  return (
    <>
      <PageHeader title="My Reservations" description="Your upcoming and past stays" />
      <Card>
        <CardContent className="p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead><TableHead>Room type</TableHead>
                <TableHead>Check-in</TableHead><TableHead>Check-out</TableHead>
                <TableHead>Nights</TableHead><TableHead>Total</TableHead>
                <TableHead>Status</TableHead><TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="font-mono text-xs">{r.id}</TableCell>
                  <TableCell className="font-medium">{r.roomType}</TableCell>
                  <TableCell className="text-muted-foreground">{r.checkIn}</TableCell>
                  <TableCell className="text-muted-foreground">{r.checkOut}</TableCell>
                  <TableCell>{r.nights}</TableCell>
                  <TableCell className="font-semibold">₹{r.total.toLocaleString()}</TableCell>
                  <TableCell><StatusBadge value={r.status} /></TableCell>
                  <TableCell className="text-right">
                    {r.status === "CONFIRMED" ? (
                      <Button variant="outline" size="sm" onClick={() => {
                        if (!window.confirm(`Cancel ${r.id}?`)) return;
                        setItems((cur) => cur.map((x) => x.id === r.id ? { ...x, status: "CANCELLED" } : x));
                        toast.success("Reservation cancelled");
                      }}>Cancel</Button>
                    ) : <span className="text-xs text-muted-foreground">—</span>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
