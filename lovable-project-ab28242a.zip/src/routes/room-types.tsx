import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { roomTypes } from "@/lib/mock-data";
import { BedDouble, Users2, IndianRupee } from "lucide-react";

export const Route = createFileRoute("/room-types")({
  head: () => ({
    meta: [
      { title: "Room Types — StayNest" },
      { name: "description", content: "Configure room categories, occupancy, base rates and amenities." },
      { property: "og:title", content: "Room Types — StayNest" },
      { property: "og:description", content: "Manage StayNest room inventory categories." },
    ],
  }),
  component: RoomTypesPage,
});

function RoomTypesPage() {
  return (
    <>
      <PageHeader
        title="Room Types"
        description="Define categories, bed configuration, occupancy and base tariff"
        actions={<Button>Add room type</Button>}
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-2">
        {roomTypes.map((r) => (
          <Card key={r.id} className="overflow-hidden">
            <div className="h-32 bg-gradient-to-br from-primary/15 via-[color:var(--gold)]/15 to-accent" />
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif text-xl">{r.name}</h3>
                    <StatusBadge value={r.status} />
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{r.bedConfig}</p>
                </div>
                <Button variant="outline" size="sm">Edit</Button>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 text-sm">
                <div className="rounded-md border p-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground"><Users2 className="h-3.5 w-3.5" /> Occupancy</div>
                  <div className="mt-1 font-semibold">{r.maxOccupancy}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground"><IndianRupee className="h-3.5 w-3.5" /> Base rate</div>
                  <div className="mt-1 font-semibold">₹{r.baseRate.toLocaleString()}</div>
                </div>
                <div className="rounded-md border p-3">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground"><BedDouble className="h-3.5 w-3.5" /> Beds</div>
                  <div className="mt-1 font-semibold">{r.bedConfig.split(" ")[0]}</div>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {r.amenities.map((a) => (
                  <Badge key={a} variant="secondary" className="rounded-md font-normal">{a}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}
