import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/lib/status-badges";
import { initialRooms, roomTypes, type RoomStatus } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/rooms")({
  head: () => ({
    meta: [
      { title: "Rooms — StayNest" },
      { name: "description", content: "Live room-status board for the property." },
      { property: "og:title", content: "Rooms — StayNest" },
      { property: "og:description", content: "Track occupancy and cleaning status." },
    ],
  }),
  component: RoomsPage,
});

const statuses: RoomStatus[] = ["AVAILABLE", "OCCUPIED", "CLEANING", "MAINTENANCE", "BLOCKED"];

function RoomsPage() {
  const [rooms, setRooms] = useState(initialRooms);

  return (
    <>
      <PageHeader title="Rooms" description="Current status across floors" actions={<Button>Add room</Button>} />
      <Card>
        <CardContent className="p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Room</TableHead><TableHead>Floor</TableHead><TableHead>Type</TableHead>
                <TableHead>Status</TableHead><TableHead className="text-right">Update status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rooms.map((r) => {
                const type = roomTypes.find((t) => t.id === r.roomTypeId);
                return (
                  <TableRow key={r.id}>
                    <TableCell className="font-semibold">Room {r.number}</TableCell>
                    <TableCell className="text-muted-foreground">{r.floor}</TableCell>
                    <TableCell>{type?.name ?? "—"}</TableCell>
                    <TableCell><StatusBadge value={r.status} /></TableCell>
                    <TableCell className="text-right">
                      <div className="inline-flex">
                        <Select
                          value={r.status}
                          onValueChange={(v) => {
                            setRooms((cur) => cur.map((x) => x.id === r.id ? { ...x, status: v as RoomStatus } : x));
                            toast.success(`Room ${r.number} → ${v}`);
                          }}
                        >
                          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                          <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
