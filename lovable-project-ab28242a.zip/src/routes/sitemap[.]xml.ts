import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "";

interface SitemapEntry { path: string; changefreq?: "weekly" | "daily"; priority?: string; }

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [
          { path: "/", changefreq: "weekly", priority: "1.0" },
          { path: "/booking", changefreq: "daily", priority: "0.9" },
          { path: "/reservations", changefreq: "weekly", priority: "0.7" },
          { path: "/profile", changefreq: "weekly", priority: "0.5" },
          { path: "/front-desk", changefreq: "daily", priority: "0.6" },
          { path: "/housekeeping", changefreq: "daily", priority: "0.6" },
          { path: "/maintenance", changefreq: "weekly", priority: "0.5" },
          { path: "/menu", changefreq: "weekly", priority: "0.6" },
          { path: "/orders", changefreq: "daily", priority: "0.5" },
          { path: "/dining", changefreq: "daily", priority: "0.5" },
          { path: "/notifications", changefreq: "daily", priority: "0.4" },
          { path: "/room-types", changefreq: "weekly", priority: "0.6" },
          { path: "/rooms", changefreq: "daily", priority: "0.5" },
          { path: "/rate-plans", changefreq: "weekly", priority: "0.5" },
          { path: "/users", changefreq: "weekly", priority: "0.4" },
          { path: "/login", changefreq: "weekly", priority: "0.3" },
        ];
        const urls = entries
          .map((e) => `  <url>\n    <loc>${BASE_URL}${e.path}</loc>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority}</priority>\n  </url>`)
          .join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});
