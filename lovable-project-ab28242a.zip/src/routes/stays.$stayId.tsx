import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { StatusBadge } from "@/lib/status-badges";
import { stays, type ChargeType, type FolioItem } from "@/lib/mock-data";
import { toast } from "sonner";
import { ArrowLeft, Plus } from "lucide-react";

export const Route = createFileRoute("/stays/$stayId")({
  head: ({ params }) => ({
    meta: [
      { title: `Stay ${params.stayId} — StayNest` },
      { name: "description", content: "Guest folio with itemised charges and checkout." },
      { property: "og:title", content: `Stay ${params.stayId} — StayNest` },
      { property: "og:description", content: "Live guest folio and checkout." },
    ],
  }),
  component: StayDetailPage,
});

const chargeTypes: ChargeType[] = ["RoomRent", "FBCharge", "LaundryCharge", "Spa", "Tax", "Discount"];

function StayDetailPage() {
  const { stayId } = Route.useParams();
  const navigate = useNavigate();
  const base = stays.find((s) => s.id === stayId) ?? stays[0];
  const [folio, setFolio] = useState<FolioItem[]>(base.folio);
  const [status, setStatus] = useState(base.status);
  const [open, setOpen] = useState(false);
  const [charge, setCharge] = useState<{ type: ChargeType; description: string; amount: string }>({
    type: "FBCharge", description: "", amount: "",
  });
  const total = folio.reduce((s, i) => s + i.amount, 0);

  return (
    <>
      <PageHeader
        title={`Folio · ${base.guest}`}
        description={`${base.roomType} · Room ${base.room} · ${base.id}`}
        actions={
          <>
            <Link to="/front-desk"><Button variant="outline"><ArrowLeft className="mr-1.5 h-4 w-4" /> Back</Button></Link>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="outline"><Plus className="mr-1.5 h-4 w-4" /> Add charge</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Post charge to folio</DialogTitle></DialogHeader>
                <div className="grid gap-3">
                  <div>
                    <Label>Type</Label>
                    <Select value={charge.type} onValueChange={(v) => setCharge({ ...charge, type: v as ChargeType })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{chargeTypes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label>Description</Label><Input value={charge.description} onChange={(e) => setCharge({ ...charge, description: e.target.value })} /></div>
                  <div><Label>Amount (₹)</Label><Input type="number" value={charge.amount} onChange={(e) => setCharge({ ...charge, amount: e.target.value })} /></div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button onClick={() => {
                    const amt = Number(charge.amount);
                    if (!charge.description || !amt) { toast.error("Description & amount required"); return; }
                    setFolio((f) => [...f, {
                      id: f.length + 1, type: charge.type, description: charge.description,
                      amount: amt, postedDate: new Date().toISOString().slice(0, 10), postedBy: "Front Desk",
                    }]);
                    toast.success("Charge posted");
                    setCharge({ type: "FBCharge", description: "", amount: "" });
                    setOpen(false);
                  }}>Post</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button
              disabled={status === "CHECKEDOUT"}
              onClick={() => {
                if (!window.confirm(`Check out ${base.guest}? Final total ₹${total.toLocaleString()}`)) return;
                setStatus("CHECKEDOUT");
                toast.success("Guest checked out");
                setTimeout(() => navigate({ to: "/front-desk" }), 800);
              }}
            >
              Checkout
            </Button>
          </>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardContent className="p-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead><TableHead>Description</TableHead>
                  <TableHead>Posted</TableHead><TableHead>By</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {folio.map((i) => (
                  <TableRow key={i.id}>
                    <TableCell><StatusBadge value={i.type} /></TableCell>
                    <TableCell>{i.description}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{i.postedDate}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{i.postedBy}</TableCell>
                    <TableCell className="text-right font-medium">₹{i.amount.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Folio balance</div>
            <div className="mt-1 font-serif text-3xl">₹{total.toLocaleString()}</div>
            <div className="mt-3"><StatusBadge value={status} /></div>
            <div className="mt-6 grid gap-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Room</span><span>{base.room}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Type</span><span>{base.roomType}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Check-in</span><span>{base.checkIn}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Charges</span><span>{folio.length}</span></div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
