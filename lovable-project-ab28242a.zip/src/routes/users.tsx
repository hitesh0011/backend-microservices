import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { initialUsers, type User, type Role } from "@/lib/mock-data";
import { StatusBadge } from "@/lib/status-badges";
import { Plus, Search } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/users")({
  head: () => ({
    meta: [
      { title: "User Management — StayNest" },
      { name: "description", content: "Administer staff and guest accounts, roles, and access." },
      { property: "og:title", content: "User Management — StayNest" },
      { property: "og:description", content: "Manage staff accounts and roles." },
    ],
  }),
  component: UsersPage,
});

const roles: Role[] = ["ADMIN", "FRONTDESK", "HOUSEKEEPING", "FBMANAGER", "REVENUEMANAGER", "GUEST"];

function UsersPage() {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Omit<User, "id" | "status">>({
    name: "", role: "FRONTDESK", email: "", phone: "", property: "StayNest Bengaluru",
  });

  const filtered = useMemo(
    () => users.filter((u) => (u.name + u.email).toLowerCase().includes(q.toLowerCase())),
    [users, q],
  );

  return (
    <>
      <PageHeader
        title="Users"
        description="Staff accounts, roles and access status"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-1.5 h-4 w-4" /> Add user</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New user</DialogTitle></DialogHeader>
              <div className="grid gap-3">
                <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
                <div>
                  <Label>Role</Label>
                  <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as Role })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{roles.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Property</Label><Input value={form.property} onChange={(e) => setForm({ ...form, property: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button
                  onClick={() => {
                    if (!form.name || !form.email) { toast.error("Name & email required"); return; }
                    setUsers((u) => [...u, { ...form, id: Math.max(...u.map((x) => x.id)) + 1, status: "ACTIVE" }]);
                    toast.success("User created");
                    setForm({ name: "", role: "FRONTDESK", email: "", phone: "", property: "StayNest Bengaluru" });
                    setOpen(false);
                  }}
                >
                  Create
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <Card>
        <CardContent className="p-4">
          <div className="mb-3 flex items-center gap-2">
            <div className="relative flex-1 max-w-sm">
              <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search name or email" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <span className="ml-auto text-xs text-muted-foreground">{filtered.length} users</span>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead><TableHead>Name</TableHead><TableHead>Role</TableHead>
                <TableHead>Email</TableHead><TableHead>Property</TableHead>
                <TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((u) => (
                <TableRow key={u.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">#{u.id.toString().padStart(4, "0")}</TableCell>
                  <TableCell className="font-medium">{u.name}</TableCell>
                  <TableCell><StatusBadge value={u.role} /></TableCell>
                  <TableCell className="text-muted-foreground">{u.email}</TableCell>
                  <TableCell className="text-muted-foreground">{u.property}</TableCell>
                  <TableCell><StatusBadge value={u.status} /></TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline" size="sm"
                      onClick={() => {
                        setUsers((cur) => cur.map((x) => x.id === u.id ? { ...x, status: x.status === "ACTIVE" ? "INACTIVE" : "ACTIVE" } : x));
                        toast.success(u.status === "ACTIVE" ? "User deactivated" : "User activated");
                      }}
                    >
                      {u.status === "ACTIVE" ? "Deactivate" : "Activate"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
